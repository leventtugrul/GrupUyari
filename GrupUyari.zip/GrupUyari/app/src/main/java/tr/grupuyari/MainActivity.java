package tr.grupuyari;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

public class MainActivity extends Activity {
    private static final int GREEN = 0xFF128C7E;
    private LinearLayout root;
    private ScrollView scroll;
    private final SimpleDateFormat fmt = new SimpleDateFormat("dd.MM HH:mm", new Locale("tr"));

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(14);
        root.setPadding(p, p, p, dp(40));
        scroll.addView(root);
        setContentView(scroll);
        Alerts.createChannel(this);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        WaListener.onChange = () -> runOnUiThread(this::render);
        render();
    }

    @Override
    protected void onPause() {
        super.onPause();
        WaListener.onChange = null;
    }

    // ------------------------------------------------------------------
    private void render() {
        int y = scroll.getScrollY();
        root.removeAllViews();
        statusCard();
        groupsCard();
        keywordsCard();
        optionsCard();
        logCard();
        scroll.post(() -> scroll.scrollTo(0, y));
    }

    private void statusCard() {
        LinearLayout c = card("Durum");
        boolean access = hasAccess();
        TextView t = text(access ? "✅ Bildirim erişimi açık" : "❌ Bildirim erişimi KAPALI — uyarılar çalışmaz", 15, true);
        t.setTextColor(access ? GREEN : 0xFFC62828);
        c.addView(t);
        if (!access) {
            c.addView(text("Aşağıdaki düğmeye bas, listeden \"Grup Uyarı\"yı aç. "
                    + "Gri/kilitli görünüyorsa: Ayarlar › Uygulamalar › Grup Uyarı › sağ üst ⋮ › "
                    + "\"Kısıtlanmış ayarlara izin ver\", sonra tekrar dene.", 13, false));
        }
        c.addView(button(access ? "Bildirim erişimi ayarları" : "Bildirim erişimini aç",
                v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))));

        Switch on = sw("Uyarılar açık", Prefs.enabled(this));
        on.setOnCheckedChangeListener((v, ch) -> Prefs.putBool(this, "enabled", ch));
        c.addView(on);

        LinearLayout row = row();
        row.addView(button("Ses / titreşim", v -> {
            Intent i = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            i.putExtra(Settings.EXTRA_CHANNEL_ID, Alerts.CHANNEL);
            startActivity(i);
        }), weight());
        row.addView(button("Test uyarısı", v -> Alerts.show(this, "test", "Test Grubu", "Levent",
                "Bu bir deneme mesajıdır. Dokununca WhatsApp açılır.", "deneme", null, "com.whatsapp")), weight());
        c.addView(row);

        PowerManager pm = getSystemService(PowerManager.class);
        if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
            c.addView(button("Pil kısıtlamasını kaldır (önerilir)", v -> {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                }
            }));
        }
    }

    private void groupsCard() {
        LinearLayout c = card("1) Takip edilecek gruplar");
        Switch all = sw("Tüm gruplar", Prefs.allGroups(this));
        all.setOnCheckedChangeListener((v, ch) -> { Prefs.putBool(this, "allGroups", ch); render(); });
        c.addView(all);

        if (!Prefs.allGroups(this)) {
            Set<String> selected = Prefs.getSet(this, Prefs.GROUPS);
            Set<String> list = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
            list.addAll(Prefs.getSet(this, Prefs.SEEN));
            list.addAll(selected);
            if (list.isEmpty()) {
                c.addView(hint("Henüz grup görülmedi. Bildirim erişimini açtıktan sonra gruplardan mesaj "
                        + "geldikçe burada listelenir; ya da grup adını aşağıya aynen yazıp ekle."));
            }
            for (String g : list) {
                CheckBox cb = new CheckBox(this);
                cb.setText(g);
                cb.setTextSize(15);
                cb.setChecked(selected.contains(g));
                cb.setOnCheckedChangeListener((v, ch) -> {
                    if (ch) Prefs.addTo(this, Prefs.GROUPS, g); else Prefs.removeFrom(this, Prefs.GROUPS, g);
                });
                cb.setOnLongClickListener(v -> {
                    new AlertDialog.Builder(this).setMessage("\"" + g + "\" listeden silinsin mi?")
                            .setPositiveButton("Sil", (d, w) -> {
                                Prefs.removeFrom(this, Prefs.GROUPS, g);
                                Prefs.removeFrom(this, Prefs.SEEN, g);
                                render();
                            }).setNegativeButton("Vazgeç", null).show();
                    return true;
                });
                c.addView(cb);
            }
            if (!list.isEmpty()) c.addView(hint("İşaretle = takip et. Silmek için uzun bas."));
            addRow(c, "Grup adı (WhatsApp'taki gibi)", s -> {
                Prefs.addTo(this, Prefs.SEEN, s);
                Prefs.addTo(this, Prefs.GROUPS, s);
            });
        }
    }

    private void keywordsCard() {
        LinearLayout c = card("2) Etiketler / anahtar kelimeler");
        Set<String> kws = Prefs.getSet(this, Prefs.KEYWORDS);
        if (kws.isEmpty()) {
            c.addView(hint("Liste boş: seçili gruplardaki TÜM mesajlar için uyarı verilir. "
                    + "Kelime eklersen sadece o kelimeleri içeren mesajlarda uyarır."));
        } else {
            c.addView(hint("Mesajda bu kelimelerden biri geçerse uyarır (büyük/küçük harf ve "
                    + "ş/s, ı/i gibi farklar önemsiz). Adının geçtiği mesajlar için adını ya da "
                    + "@numaranı ekleyebilirsin."));
        }
        for (String k : kws) {
            LinearLayout r = row();
            TextView chip = text("🏷  " + k, 15, false);
            chip.setPadding(dp(8), dp(8), dp(8), dp(8));
            r.addView(chip, weight());
            Button del = button("✕", v -> { Prefs.removeFrom(this, Prefs.KEYWORDS, k); render(); });
            r.addView(del);
            c.addView(r);
        }
        addRow(c, "Yeni kelime (ör. acil, fatura, toplantı)", s -> Prefs.addTo(this, Prefs.KEYWORDS, s));
    }

    private void optionsCard() {
        LinearLayout c = card("3) Diğer");
        Switch hide = sw("Takip edilen gruplarda eşleşmeyen WhatsApp bildirimlerini gizle",
                Prefs.hideOthers(this));
        hide.setOnCheckedChangeListener((v, ch) -> Prefs.putBool(this, "hideOthers", ch));
        c.addView(hide);
        c.addView(hint("Önemli: WhatsApp'ta grubu \"sessize al\"ırsan WhatsApp bildirim üretmez, "
                + "bu uygulama da mesajı göremez. Gürültüyü kesmek için grubu sessize almak yerine "
                + "WhatsApp'ta grup bilgisi › Özel bildirimler › Ton: Yok, Titreşim: Kapalı yap; "
                + "sesli uyarıyı bu uygulama verir."));
    }

    private void logCard() {
        LinearLayout c = card("Son uyarılar");
        JSONArray log = Prefs.log(this);
        if (log.length() == 0) {
            c.addView(hint("Henüz uyarı yok."));
            return;
        }
        c.addView(hint("Dokun → mesajın olduğu sohbete git."));
        int n = Math.min(log.length(), 100);
        for (int i = 0; i < n; i++) {
            JSONObject o = log.optJSONObject(i);
            if (o == null) continue;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(10), dp(8), dp(10), dp(8));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xFFF1F8F6);
            bg.setCornerRadius(dp(8));
            item.setBackground(bg);

            String kw = o.optString("kw");
            TextView h = text(o.optString("group") + (TextUtils.isEmpty(kw) ? "" : "  🏷 " + kw), 14, true);
            h.setTextColor(GREEN);
            item.addView(h);
            String sender = o.optString("sender");
            item.addView(text((TextUtils.isEmpty(sender) ? "" : sender + ": ") + o.optString("text"), 14, false));
            TextView when = text(fmt.format(new Date(o.optLong("time"))), 11, false);
            when.setTextColor(Color.GRAY);
            item.addView(when);

            String id = o.optString("id"), pkg = o.optString("pkg", "com.whatsapp");
            item.setOnClickListener(v -> {
                if (!Alerts.open(this, id, pkg)) toast("WhatsApp açılamadı");
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(6);
            c.addView(item, lp);
        }
        c.addView(button("Geçmişi temizle", v -> { Prefs.clearLog(this); render(); }));
    }

    // ------------------------------------------------------------------
    private boolean hasAccess() {
        String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        ComponentName me = new ComponentName(this, WaListener.class);
        return flat != null && flat.contains(me.flattenToString());
    }

    interface OnText { void add(String s); }

    private void addRow(LinearLayout c, String hintText, OnText cb) {
        LinearLayout r = row();
        EditText e = new EditText(this);
        e.setHint(hintText);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        r.addView(e, weight());
        r.addView(button("Ekle", v -> {
            String s = e.getText().toString().trim();
            if (s.isEmpty()) return;
            cb.add(s);
            render();
        }));
        c.addView(r);
    }

    private LinearLayout card(String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setStroke(dp(1), 0xFFDDDDDD);
        bg.setCornerRadius(dp(12));
        c.setBackground(bg);
        TextView t = text(title, 17, true);
        t.setPadding(0, 0, 0, dp(6));
        c.addView(t);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(12);
        root.addView(c, lp);
        return c;
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(0xFF222222);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView hint(String s) {
        TextView t = text(s, 13, false);
        t.setTextColor(0xFF666666);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private Switch sw(String s, boolean on) {
        Switch w = new Switch(this);
        w.setText(s);
        w.setTextSize(15);
        w.setChecked(on);
        w.setPadding(0, dp(8), 0, dp(8));
        return w;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
