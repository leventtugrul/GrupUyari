package tr.grupuyari;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

/** Ayarlar ve uyarı geçmişi (SharedPreferences). */
public final class Prefs {
    public static final String GROUPS = "groups";     // seçili gruplar
    public static final String SEEN = "seen";         // bildirimlerde görülen gruplar
    public static final String KEYWORDS = "keywords"; // anahtar kelimeler
    private static final int MAX_LOG = 300;
    private static final Locale TR = new Locale("tr", "TR");

    private Prefs() {}

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("ayar", Context.MODE_PRIVATE);
    }

    static boolean getBool(Context c, String k, boolean def) { return sp(c).getBoolean(k, def); }
    static void putBool(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }

    static boolean enabled(Context c) { return getBool(c, "enabled", true); }
    static boolean allGroups(Context c) { return getBool(c, "allGroups", false); }
    static boolean hideOthers(Context c) { return getBool(c, "hideOthers", false); }

    static Set<String> getSet(Context c, String key) {
        return new TreeSet<>(sp(c).getStringSet(key, new HashSet<>()));
    }

    static void putSet(Context c, String key, Set<String> s) {
        sp(c).edit().putStringSet(key, new HashSet<>(s)).apply();
    }

    static boolean addTo(Context c, String key, String value) {
        Set<String> s = getSet(c, key);
        boolean added = s.add(value);
        if (added) putSet(c, key, s);
        return added;
    }

    static void removeFrom(Context c, String key, String value) {
        Set<String> s = getSet(c, key);
        if (s.remove(value)) putSet(c, key, s);
    }

    /** Türkçe karakter ve büyük/küçük harf farkını yok sayan karşılaştırma için. */
    static String fold(String s) {
        if (s == null) return "";
        String x = s.toLowerCase(TR);
        StringBuilder b = new StringBuilder(x.length());
        for (int i = 0; i < x.length(); i++) {
            char ch = x.charAt(i);
            switch (ch) {
                case 'ı': ch = 'i'; break;
                case 'ş': ch = 's'; break;
                case 'ğ': ch = 'g'; break;
                case 'ü': ch = 'u'; break;
                case 'ö': ch = 'o'; break;
                case 'ç': ch = 'c'; break;
                case 'â': ch = 'a'; break;
                case 'î': ch = 'i'; break;
                case 'û': ch = 'u'; break;
                case '̇': continue; // "İ".toLowerCase artığı
                default: break;
            }
            b.append(ch);
        }
        return b.toString().trim();
    }

    /** Mesaj eşleşirse eşleşen kelimeyi, kelime listesi boşsa "" döner; eşleşmezse null. */
    static String match(Context c, String text) {
        Set<String> kws = getSet(c, KEYWORDS);
        if (kws.isEmpty()) return "";
        String t = fold(text);
        for (String k : kws) {
            String fk = fold(k);
            if (!fk.isEmpty() && t.contains(fk)) return k;
        }
        return null;
    }

    // ---- Uyarı geçmişi ----
    static synchronized JSONArray log(Context c) {
        try {
            return new JSONArray(sp(c).getString("log", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    static synchronized void addLog(Context c, JSONObject o) {
        JSONArray old = log(c);
        JSONArray n = new JSONArray();
        n.put(o);
        for (int i = 0; i < old.length() && n.length() < MAX_LOG; i++) n.put(old.opt(i));
        sp(c).edit().putString("log", n.toString()).apply();
    }

    static synchronized void clearLog(Context c) {
        sp(c).edit().putString("log", "[]").apply();
    }
}
