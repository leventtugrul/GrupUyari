package tr.grupuyari;

import android.app.ActivityOptions;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.StyleSpan;

import java.util.LinkedHashMap;
import java.util.Map;

/** Kendi uyarı bildirimimizi gösterir ve mesaja gitmeyi sağlar. */
public final class Alerts {
    static final String CHANNEL = "grup_uyari";
    private static int nextId = (int) (System.currentTimeMillis() % 100000);

    /** WhatsApp'ın "sohbete git" intent'leri (uygulama açıkken hafızada tutulur). */
    static final Map<String, PendingIntent> INTENTS = new LinkedHashMap<String, PendingIntent>() {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, PendingIntent> e) {
            return size() > 300;
        }
    };

    private Alerts() {}

    static void createChannel(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Grup mesajı uyarıları",
                NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Seçtiğin gruplardan eşleşen WhatsApp mesajları");
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 400, 200, 400, 200, 600});
        ch.enableLights(true);
        ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build());
        nm.createNotificationChannel(ch);
    }

    static void show(Context c, String logId, String group, String sender, String text,
                     String keyword, PendingIntent waIntent, String pkg) {
        createChannel(c);
        PendingIntent pi = waIntent != null ? waIntent : launchWhatsApp(c, pkg);

        String body = (sender == null || sender.isEmpty()) ? text : sender + ": " + text;
        CharSequence styled = highlight(body, keyword);
        String title = "🔔 " + group + (keyword != null && !keyword.isEmpty() ? "  •  " + keyword : "");

        Notification.Builder b = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_bell)
                .setContentTitle(title)
                .setContentText(styled)
                .setStyle(new Notification.BigTextStyle().bigText(styled))
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setShowWhen(true)
                .setColor(0xFF128C7E);
        if (pi != null) b.setContentIntent(pi);

        c.getSystemService(NotificationManager.class).notify(nextId++, b.build());
    }

    private static CharSequence highlight(String body, String kw) {
        if (kw == null || kw.isEmpty() || body == null) return body;
        SpannableString s = new SpannableString(body);
        String fb = Prefs.fold(body), fk = Prefs.fold(kw);
        // fold uzunluğu genelde aynı kalır; değilse vurgulamadan geç
        if (fb.length() != body.length()) return body;
        int from = 0, idx;
        while (!fk.isEmpty() && (idx = fb.indexOf(fk, from)) >= 0) {
            int end = Math.min(idx + fk.length(), s.length());
            s.setSpan(new StyleSpan(Typeface.BOLD), idx, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            from = end;
        }
        return s;
    }

    static PendingIntent launchWhatsApp(Context c, String pkg) {
        Intent i = c.getPackageManager().getLaunchIntentForPackage(
                pkg != null ? pkg : "com.whatsapp");
        if (i == null) i = c.getPackageManager().getLaunchIntentForPackage("com.whatsapp.w4b");
        if (i == null) return null;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(c, 0, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Uygulama içi listeden tıklanınca mesaja/sohbete git. */
    static boolean open(Context c, String logId, String pkg) {
        PendingIntent pi;
        synchronized (INTENTS) { pi = INTENTS.get(logId); }
        if (pi == null) pi = launchWhatsApp(c, pkg);
        if (pi == null) return false;
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                ActivityOptions o = ActivityOptions.makeBasic();
                o.setPendingIntentBackgroundActivityStartMode(
                        ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED);
                pi.send(c, 0, null, null, null, null, o.toBundle());
            } else {
                pi.send();
            }
            return true;
        } catch (Exception e) {
            PendingIntent wa = launchWhatsApp(c, pkg);
            try { if (wa != null) { wa.send(); return true; } } catch (Exception ignored) {}
            return false;
        }
    }
}
