package tr.grupuyari;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Person;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** WhatsApp bildirimlerini okur, kurallara uyan grup mesajları için uyarı verir. */
public class WaListener extends NotificationListenerService {
    static final Set<String> PKGS = new HashSet<>(Arrays.asList("com.whatsapp", "com.whatsapp.w4b"));
    static volatile boolean connected = false;
    static volatile Runnable onChange; // arayüzü yenilemek için

    private static final long MAX_AGE_MS = 10 * 60 * 1000L;
    private final LinkedHashSet<String> recent = new LinkedHashSet<>();

    @Override
    public void onListenerConnected() {
        connected = true;
        Alerts.createChannel(this);
        notifyUi();
    }

    @Override
    public void onListenerDisconnected() {
        connected = false;
        notifyUi();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            handle(sbn);
        } catch (Throwable ignored) {
            // bir bildirim yüzünden servis çökmesin
        }
    }

    private void handle(StatusBarNotification sbn) {
        if (!PKGS.contains(sbn.getPackageName())) return;
        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        if ((n.flags & Notification.FLAG_ONGOING_EVENT) != 0) return;

        Bundle ex = n.extras;
        String conv = cs(ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE));
        String title = cs(ex.getCharSequence(Notification.EXTRA_TITLE));
        boolean isGroup = Build.VERSION.SDK_INT >= 28
                && ex.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false);

        String group = null, titleSender = null;
        if (!conv.isEmpty()) {
            group = conv;
        } else if (title.contains(": ")) {          // eski biçim: "Grup: Gönderen"
            int i = title.indexOf(": ");
            group = title.substring(0, i);
            titleSender = title.substring(i + 2);
        } else if (isGroup) {
            group = title;
        }
        if (group == null) return;                    // bireysel sohbet
        group = cleanGroup(group);
        if (group.isEmpty()) return;

        if (Prefs.addTo(this, Prefs.SEEN, group)) notifyUi();
        if (!Prefs.enabled(this)) return;

        boolean groupOk = Prefs.allGroups(this) || Prefs.getSet(this, Prefs.GROUPS).contains(group);
        if (!groupOk) return;

        boolean anyMatch = false;
        long now = System.currentTimeMillis();
        for (Msg m : extract(ex, titleSender, sbn.getPostTime())) {
            if (m.text.isEmpty()) continue;
            if (m.time > 0 && now - m.time > MAX_AGE_MS) continue; // eski mesaj
            String key = group + "|" + m.time + "|" + m.sender + "|" + m.text;
            if (recent.contains(key)) { anyMatch = anyMatch || Prefs.match(this, m.text) != null; continue; }
            remember(key);

            String kw = Prefs.match(this, m.text);
            if (kw == null) continue;
            anyMatch = true;
            alert(group, m, kw, n.contentIntent, sbn.getPackageName());
        }

        if (!anyMatch && Prefs.hideOthers(this)) {
            cancelNotification(sbn.getKey());
        }
    }

    private void alert(String group, Msg m, String kw, PendingIntent pi, String pkg) {
        String id = "a" + System.nanoTime();
        if (pi != null) synchronized (Alerts.INTENTS) { Alerts.INTENTS.put(id, pi); }
        try {
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("group", group);
            o.put("sender", m.sender);
            o.put("text", m.text);
            o.put("kw", kw);
            o.put("time", m.time > 0 ? m.time : System.currentTimeMillis());
            o.put("pkg", pkg);
            Prefs.addLog(this, o);
        } catch (Exception ignored) {}
        Alerts.show(this, id, group, m.sender, m.text, kw, pi, pkg);
        notifyUi();
    }

    private void remember(String key) {
        recent.add(key);
        if (recent.size() > 500) {
            String first = recent.iterator().next();
            recent.remove(first);
        }
    }

    static final class Msg {
        String sender = "", text = "";
        long time;
    }

    @SuppressWarnings("deprecation")
    private static List<Msg> extract(Bundle ex, String titleSender, long postTime) {
        List<Msg> out = new ArrayList<>();
        Parcelable[] arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES);
        if (arr != null && arr.length > 0) {
            for (Parcelable p : arr) {
                if (!(p instanceof Bundle)) continue;
                Bundle b = (Bundle) p;
                Msg m = new Msg();
                m.text = cs(b.getCharSequence("text"));
                m.time = b.getLong("time", 0);
                m.sender = cs(b.getCharSequence("sender"));
                if (m.sender.isEmpty() && Build.VERSION.SDK_INT >= 28) {
                    Parcelable sp = b.getParcelable("sender_person");
                    if (sp instanceof Person) m.sender = cs(((Person) sp).getName());
                }
                out.add(m);
            }
            return out;
        }
        Msg m = new Msg();
        CharSequence big = ex.getCharSequence(Notification.EXTRA_BIG_TEXT);
        m.text = cs(big != null ? big : ex.getCharSequence(Notification.EXTRA_TEXT));
        m.sender = titleSender != null ? titleSender : "";
        m.time = postTime;
        out.add(m);
        return out;
    }

    /** "Grup Adı (3 mesaj)" -> "Grup Adı" */
    static String cleanGroup(String g) {
        return g.replaceAll("\\s*\\(\\d+[^)]*\\)\\s*$", "").trim();
    }

    static String cs(CharSequence c) {
        return c == null ? "" : c.toString().trim();
    }

    private static void notifyUi() {
        Runnable r = onChange;
        if (r != null) r.run();
    }
}
