# Grup Uyarı — WhatsApp grup mesajı uyarıcısı (Android)

Seçtiğin WhatsApp gruplarından, seçtiğin kelimeleri (etiketleri) içeren mesaj gelince
sesli/titreşimli ayrı bir uyarı verir, mesajı gösterir; uyarıya dokununca WhatsApp'ta o sohbet açılır.
Kelime listesi boşsa seçili gruplardaki tüm mesajlarda uyarır. Normal WhatsApp ve WhatsApp Business desteklenir.

## APK'yı elde etme (bilgisayara bir şey kurmadan)
1. github.com'da ücretsiz hesap aç, **New repository** ile boş bir depo oluştur (Private olabilir).
2. Depo sayfasında **Add file › Upload files** de, bu klasörün içindeki her şeyi
   (`.github` klasörü dahil) sürükleyip bırak, **Commit changes**.
   - `.github` gizli klasör olduğu için görünmezse: **Add file › Create new file** ile
     ad kısmına `.github/workflows/build.yml` yaz ve dosya içeriğini yapıştır.
3. **Actions** sekmesinde "APK derle" çalışır (~3-5 dk). Bitince çalıştırmaya tıkla,
   en altta **GrupUyari-apk**'yı indir; zip'in içinden `GrupUyari.apk` çıkar.

Android Studio'n varsa: klasörü aç › Build › Build APK(s).

## Telefona kurulum
1. APK'yı telefona at, aç, "Bilinmeyen kaynaklardan yüklemeye izin ver" de.
2. Uygulamayı aç, bildirim iznine **İzin ver**.
3. **Bildirim erişimini aç** › listeden **Grup Uyarı**'yı aç.
   - Android 13+ "Kısıtlanmış ayar" diyip izin vermezse: Ayarlar › Uygulamalar › Grup Uyarı ›
     sağ üst **⋮** › **Kısıtlanmış ayarlara izin ver**, sonra tekrar dene.
4. **Pil kısıtlamasını kaldır**'a bas (Xiaomi/Samsung/Huawei'de arka planda kapanmasın diye;
   Xiaomi'de ayrıca "Otomatik başlat"ı aç).
5. Gruplardan mesaj geldikçe grup adları listede belirir; takip etmek istediklerini işaretle.
   İstersen grup adını elle de ekleyebilirsin (WhatsApp'taki adıyla birebir).
6. Etiket/kelime ekle (ör. `acil`, `fatura`, `beyanname`, adın). **Test uyarısı** ile sesi dene.

## Bilmen gerekenler
- **Grubu WhatsApp'ta sessize alma.** Sessizdeki gruplar için WhatsApp bildirim üretmez,
  uygulama da göremez. Bunun yerine WhatsApp'ta grup bilgisi › Özel bildirimler ›
  Ton: Yok, Titreşim: Kapalı yap. Ya da "Diğer" bölümündeki
  "eşleşmeyen bildirimleri gizle" seçeneğini aç.
- Uygulama sadece telefona düşen bildirimleri okur; geçmiş mesajları ya da sen o sohbet
  açıkken gelen mesajları göremez.
- "Son uyarılar" listesindeki eski kayıtlara dokunmak (uygulama yeniden başladıysa)
  ilgili sohbet yerine WhatsApp'ın ana ekranını açabilir; bildirime dokunmak doğrudan sohbete gider.
- Veriler sadece telefonda tutulur, hiçbir yere gönderilmez; internet izni yoktur.
